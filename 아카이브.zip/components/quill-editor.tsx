"use client";

import dynamic from "next/dynamic";
import { useEffect, useMemo, useRef } from "react";
import "react-quill-new/dist/quill.snow.css";

import hljs from "highlight.js/lib/core";

// ✅ languages
import plaintext from "highlight.js/lib/languages/plaintext";
import bash from "highlight.js/lib/languages/bash";
import cpp from "highlight.js/lib/languages/cpp";
import csharp from "highlight.js/lib/languages/csharp";
import css from "highlight.js/lib/languages/css";
import diff from "highlight.js/lib/languages/diff";
import xml from "highlight.js/lib/languages/xml";
import java from "highlight.js/lib/languages/java";
import javascript from "highlight.js/lib/languages/javascript";
import markdown from "highlight.js/lib/languages/markdown";
import php from "highlight.js/lib/languages/php";
import python from "highlight.js/lib/languages/python";
import ruby from "highlight.js/lib/languages/ruby";
import sql from "highlight.js/lib/languages/sql";

import "highlight.js/styles/github-dark.css";

const ReactQuill = dynamic(() => import("react-quill-new"), {
  ssr: false,
}) as any;

const HLJS_READY_KEY = "__hljs_quill_ready__";

function ensureHljsOnWindowOnce() {
  if (typeof window === "undefined") return;
  const w = window as any;

  if (w.hljs && w[HLJS_READY_KEY]) return;

  try {
    hljs.registerLanguage("plaintext", plaintext);
    hljs.registerLanguage("bash", bash);
    hljs.registerLanguage("cpp", cpp);
    hljs.registerLanguage("csharp", csharp);
    hljs.registerLanguage("css", css);
    hljs.registerLanguage("diff", diff);
    hljs.registerLanguage("xml", xml);
    hljs.registerLanguage("java", java);
    hljs.registerLanguage("javascript", javascript);
    hljs.registerLanguage("markdown", markdown);
    hljs.registerLanguage("php", php);
    hljs.registerLanguage("python", python);
    hljs.registerLanguage("ruby", ruby);
    hljs.registerLanguage("sql", sql);
    hljs.registerLanguage("jsx", javascript);
  } catch {
    // ignore
  }

  w.hljs = w.hljs || hljs;
  w[HLJS_READY_KEY] = true;
}

function injectDataLanguage(html: string) {
  if (!html) return html;
  if (html.includes("data-language=")) return html;
  if (!html.includes("language-")) return html;
  if (typeof window === "undefined" || typeof DOMParser === "undefined")
    return html;

  const mayHaveTargets =
    html.includes("ql-syntax") ||
    html.includes("<pre") ||
    html.includes("<code");
  if (!mayHaveTargets) return html;

  try {
    const doc = new DOMParser().parseFromString(html, "text/html");
    let mutated = false;

    doc.querySelectorAll("pre.ql-syntax").forEach((pre) => {
      if (pre.getAttribute("data-language")) return;

      const cls = (pre.getAttribute("class") || "").split(/\s+/);
      const langClass = cls.find((c) => c.startsWith("language-"));
      if (!langClass) return;

      const lang = langClass.replace("language-", "").trim().toLowerCase();
      if (!lang) return;

      pre.setAttribute("data-language", lang);
      mutated = true;
    });

    doc.querySelectorAll("pre code").forEach((code) => {
      if (code.getAttribute("data-language")) return;

      const cls = (code.getAttribute("class") || "").split(/\s+/);
      const langClass = cls.find((c) => c.startsWith("language-"));
      if (!langClass) return;

      const lang = langClass.replace("language-", "").trim().toLowerCase();
      if (!lang) return;

      code.setAttribute("data-language", lang);
      mutated = true;
    });

    if (!mutated) return html;
    const out = doc.body.innerHTML;
    return out === html ? html : out;
  } catch {
    return html;
  }
}

type QuillEditorProps = {
  value: string;
  onChange: (v: string) => void;

  /** ✅ 문항(퀴즈 질문)에서는 false로 */
  stickyToolbar?: boolean;
  /** sticky일 때 헤더 높이만큼 (기본 56px) */
  stickyTopPx?: number;
  /** 본문 폭 좁히기 (기본 760) */
  maxWidthPx?: number;

  /** ✅ 높이 조절 (기본 420) */
  minHeightPx?: number;

  /** ✅ placeholder */
  placeholder?: string;
};

export default function QuillEditor({
  value,
  onChange,
  stickyToolbar = true,
  stickyTopPx = 56,
  maxWidthPx = 760,
  minHeightPx = 420,
  placeholder,
}: QuillEditorProps) {
  useEffect(() => {
    ensureHljsOnWindowOnce();
  }, []);

  const quillRef = useRef<any>(null);
  const lastEmittedRef = useRef<string>("");

  const modules = useMemo(() => {
    return {
      syntax: {
        highlight: (text: string) => {
          const w = window as any;
          const engine = w?.hljs || hljs;
          return engine.highlightAuto(text).value;
        },
        languages: [
          { key: "plain", label: "Plain" },
          { key: "bash", label: "Bash" },
          { key: "cpp", label: "C++" },
          { key: "csharp", label: "C#" },
          { key: "css", label: "CSS" },
          { key: "diff", label: "Diff" },
          { key: "xml", label: "HTML/XML" },
          { key: "java", label: "Java" },
          { key: "javascript", label: "JavaScript" },
          { key: "markdown", label: "Markdown" },
          { key: "php", label: "PHP" },
          { key: "python", label: "Python" },
          { key: "ruby", label: "Ruby" },
          { key: "sql", label: "SQL" },
        ],
      },
      toolbar: [
        [{ header: [1, 2, 3, false] }],
        ["bold", "italic", "underline", "strike"],
        [{ list: "ordered" }, { list: "bullet" }],
        ["blockquote", "code-block"],
        ["link", "image"],
        ["clean"],
      ],
    };
  }, []);

  // ✅ 파란 영역(ql-container) 아무데나 클릭해도 커서 들어가게
  const handleMouseDownCapture = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement | null;
    if (!target) return;

    if (target.closest(".ql-toolbar")) return;

    const container = target.closest(".quill-editor .ql-container.ql-snow");
    if (!container) return;

    const inEditor = !!target.closest(".ql-editor");
    const isNonTextTarget = !!target.closest(
      "img, table, thead, tbody, tr, td, th, pre, code, .ql-syntax",
    );
    if (inEditor && !isNonTextTarget) return;

    const quill = quillRef.current?.getEditor?.();
    if (quill) {
      quill.focus();
      const len = quill.getLength();
      quill.setSelection(len, 0, "silent");
      return;
    }

    const editorEl = container.querySelector(
      ".ql-editor",
    ) as HTMLElement | null;
    editorEl?.focus();
  };

  // sticky일 때는 overflow-hidden이 sticky 깨뜨리니까 제거
  const wrapperClass = stickyToolbar
    ? "rounded-md border border-border editor-dark"
    : "rounded-md border border-border overflow-hidden editor-dark";

  return (
    <div className={wrapperClass} onMouseDownCapture={handleMouseDownCapture}>
      <ReactQuill
        ref={(instance: any) => {
          quillRef.current = instance;
        }}
        value={value}
        placeholder={placeholder}
        onChange={(html: string) => {
          ensureHljsOnWindowOnce();
          const next = injectDataLanguage(html);
          if (next === lastEmittedRef.current) return;
          lastEmittedRef.current = next;
          onChange(next);
        }}
        modules={modules}
        theme="snow"
        className="quill-editor"
      />

      <style jsx global>{`
        .quill-editor .ql-container {
          min-height: ${minHeightPx}px;
        }

        .quill-editor .ql-editor {
          min-height: ${minHeightPx}px;
          font-size: 16px;
          line-height: 1.7;

          max-width: ${maxWidthPx}px;
          margin-left: auto;
          margin-right: auto;

          padding-left: 16px;
          padding-right: 16px;
        }

        /* ✅ 툴바 고정은 옵션으로 */
        .editor-dark .ql-toolbar.ql-snow {
          background: color-mix(in oklab, var(--color-card) 92%, black 8%);
          border-color: var(--color-border);
        }

        ${stickyToolbar
          ? `
        .editor-dark .ql-toolbar.ql-snow {
          position: sticky;
          top: ${stickyTopPx}px;
          z-index: 100;
        }`
          : `
        .editor-dark .ql-toolbar.ql-snow {
          position: static;
        }`}

        .editor-dark .ql-container.ql-snow {
          border-color: var(--color-border);
        }
        .editor-dark .ql-editor {
          background: var(--color-card);
          color: var(--color-card-foreground);
        }
        .editor-dark .ql-editor.ql-blank::before {
          color: color-mix(
            in oklab,
            var(--color-muted-foreground) 70%,
            transparent 30%
          );
        }

        .editor-dark .ql-snow .ql-stroke {
          stroke: color-mix(
            in oklab,
            var(--color-foreground) 85%,
            transparent 15%
          );
        }
        .editor-dark .ql-snow .ql-fill {
          fill: color-mix(
            in oklab,
            var(--color-foreground) 85%,
            transparent 15%
          );
        }
        .editor-dark .ql-snow .ql-picker {
          color: var(--color-foreground);
        }
        .editor-dark .ql-snow .ql-picker-options {
          background: var(--color-popover);
          border-color: var(--color-border);
        }

        .editor-dark .ql-syntax {
          background: color-mix(in oklab, var(--color-muted) 35%, black 65%);
          color: var(--color-foreground);
          border: 1px solid var(--color-border);
          padding: 12px 14px;
          border-radius: var(--radius-lg);
          overflow-x: auto;
        }
      `}</style>
    </div>
  );
}
