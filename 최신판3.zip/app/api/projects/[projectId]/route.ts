import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { sql } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type PatchBody = { name?: string; slug?: string };

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ projectId: string }> },
) {
  try {
    const user = await getCurrentUser();
    if (!user)
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
    if (user.user_role !== "ADMIN")
      return NextResponse.json({ message: "Forbidden" }, { status: 403 });

    const { projectId } = await context.params;
    const pid = Number(projectId);
    if (!Number.isFinite(pid) || pid <= 0) {
      return NextResponse.json(
        { message: "Invalid projectId" },
        { status: 400 },
      );
    }

    const body = (await req.json().catch(() => ({}))) as PatchBody;
    const name = body.name !== undefined ? String(body.name).trim() : undefined;
    const slug =
      body.slug !== undefined
        ? String(body.slug).trim().toLowerCase()
        : undefined;

    if (name !== undefined && !name) {
      return NextResponse.json({ message: "name required" }, { status: 400 });
    }
    if (slug !== undefined && !slug) {
      return NextResponse.json({ message: "slug required" }, { status: 400 });
    }

    const rows = await sql<{ id: number }>`
      update public.projects
      set
        name = coalesce(${name ?? null}, name),
        slug = coalesce(${slug ?? null}, slug)
      where id = ${pid}
      returning id
    `;

    if (rows.length === 0) {
      return NextResponse.json({ message: "Not found" }, { status: 404 });
    }

    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json(
      { message: e instanceof Error ? e.message : "Server error" },
      { status: 500 },
    );
  }
}

export async function DELETE(
  _req: NextRequest,
  context: { params: Promise<{ projectId: string }> },
) {
  try {
    const user = await getCurrentUser();
    if (!user)
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
    if (user.user_role !== "ADMIN")
      return NextResponse.json({ message: "Forbidden" }, { status: 403 });

    const { projectId } = await context.params;
    const pid = Number(projectId);
    if (!Number.isFinite(pid) || pid <= 0) {
      return NextResponse.json(
        { message: "Invalid projectId" },
        { status: 400 },
      );
    }

    // project_categories / project_files는 FK CASCADE로 같이 삭제됨(설계대로)
    const rows = await sql<{ id: number }>`
      delete from public.projects
      where id = ${pid}
      returning id
    `;

    if (rows.length === 0) {
      return NextResponse.json({ message: "Not found" }, { status: 404 });
    }

    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json(
      { message: e instanceof Error ? e.message : "Server error" },
      { status: 500 },
    );
  }
}
